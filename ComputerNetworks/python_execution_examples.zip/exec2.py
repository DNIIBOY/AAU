def addTwoNumbers(a,b):
    return a+b

def main():
    a = 1
    b = 2
    print(addTwoNumbers(a,b))

main()
