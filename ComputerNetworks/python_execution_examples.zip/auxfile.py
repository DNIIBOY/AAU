def addTwoNumbers(a,b):
    return a+b

def main():
    a = 1
    b = 2
    print(addTwoNumbers(a,b))

# Call the main fucntion only if the file has not been
# imported into another program
if __name__ == "__main__":
    main()
